package com.aurawall.app

import android.app.*
import android.app.WallpaperManager
import android.content.*
import android.graphics.Bitmap
import android.os.*
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.*
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.*
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.io.File
import java.io.FileOutputStream

data class Wallpaper(val id:String,val path:String,val thumbs:Thumbs)
data class Thumbs(@SerializedName("large") val large:String,@SerializedName("original") val original:String)
data class ApiResponse(val data:List<Wallpaper>)

interface ApiService {
    @GET("search")
    suspend fun search(
        @Query("q") q:String,
        @Query("categories") categories:String="111",
        @Query("purity") purity:String="100",
        @Query("sorting") sorting:String="hot",
        @Query("page") page:Int=1
    ):ApiResponse
}
object API {
    val service=Retrofit.Builder().baseUrl("https://wallhaven.cc/api/v1/")
        .addConverterFactory(GsonConverterFactory.create()).build().create(ApiService::class.java)
}

class MainActivity:AppCompatActivity(){
    private lateinit var grid:RecyclerView
    private lateinit var adapter:WallAdapter
    private val items=ArrayList<Wallpaper>()
    private val prefs by lazy{getSharedPreferences("aurawall",0)}
    private var page=1
    private var loading=false
    private var query="anime"
    private val favorites get()=prefs.getStringSet("favorites",emptySet())?:emptySet()

    override fun onCreate(b:Bundle?){
        super.onCreate(b)
        setContentView(buildUI())
        load(true)
    }

    private fun buildUI():View{
        val root=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(24),dp(24),dp(24),dp(8))
            setBackgroundColor(android.graphics.Color.rgb(7,7,9))
        }
        val title=TextView(this).apply{
            text="✨ AuraWall"
            textSize=28f
            setTextColor(android.graphics.Color.WHITE)
            setTypeface(null,android.graphics.Typeface.BOLD)
        }
        root.addView(title,LinearLayout.LayoutParams(-1,dp(60)))
        val search=EditText(this).apply{
            hint="Search anime, cars, nature..."
            setText(query)
            singleLine=true
            setTextColor(android.graphics.Color.WHITE)
            setHintTextColor(android.graphics.Color.GRAY)
        }
        root.addView(search,LinearLayout.LayoutParams(-1,dp(60)))
        val searchBtn=MaterialButton(this).apply{
            text="SEARCH"
            setOnClickListener{query=search.text.toString().ifBlank{"anime"};load(true)}
        }
        root.addView(searchBtn)
        val chips=ChipGroup(this).apply{
            isSingleLine=true
            setPadding(0,dp(8),0,dp(8))
        }
        listOf("Anime","Cars","Nature","Gaming","Space","Minimal","AMOLED").forEach{c->
            val chip=Chip(this).apply{text=c;isCheckable=true;setOnClickListener{
                query=when(c){"Cars"->"cars";"Nature"->"nature";"Gaming"->"gaming";"Space"->"space";"Minimal"->"minimal";"AMOLED"->"black";else->"anime"}
                search.setText(query);load(true)
            }}
            chips.addView(chip)
        }
        root.addView(chips)
        grid=RecyclerView(this).apply{
            layoutManager=GridLayoutManager(this@MainActivity,2)
            setPadding(0,dp(8),0,dp(80))
            clipToPadding=false
        }
        adapter=WallAdapter()
        grid.adapter=adapter
        grid.addOnScrollListener(object:RecyclerView.OnScrollListener(){
            override fun onScrolled(rv:RecyclerView,dx:Int,dy:Int){
                if(dy>0 && !loading && !rv.canScrollVertically(1)) load(false)
            }
        })
        root.addView(grid,LinearLayout.LayoutParams(-1,0,1f))
        return root
    }

    private fun load(reset:Boolean){
        if(loading)return
        if(reset){page=1;items.clear();adapter.notifyDataSetChanged()}
        loading=true
        CoroutineScope(Dispatchers.IO).launch{
            try{
                val result=API.service.search(query=query,page=page).data
                withContext(Dispatchers.Main){
                    val start=items.size
                    items.addAll(result.filter{w->items.none{x->x.id==w.id}})
                    adapter.notifyItemRangeInserted(start,items.size-start)
                    page++
                }
            }catch(e:Exception){
                withContext(Dispatchers.Main){Toast.makeText(this@MainActivity,"Internet/API error",Toast.LENGTH_SHORT).show()}
            }finally{loading=false}
        }
    }

    inner class WallAdapter:RecyclerView.Adapter<WallHolder>(){
        override fun onCreateViewHolder(p:ViewGroup,t:Int):WallHolder{
            val box=FrameLayout(p.context)
            box.layoutParams=RecyclerView.LayoutParams(-1,dp(260))
            val img=ImageView(p.context).apply{scaleType=ImageView.ScaleType.CENTER_CROP}
            box.addView(img,FrameLayout.LayoutParams(-1,-1))
            return WallHolder(box,img)
        }
        override fun getItemCount()=items.size
        override fun onBindViewHolder(h:WallHolder,pos:Int){
            val w=items[pos]
            Glide.with(h.image).load(w.thumbs.large).into(h.image)
            h.image.setOnClickListener{showDetails(w)}
        }
    }
    inner class WallHolder(v:View,val image:ImageView):RecyclerView.ViewHolder(v)

    private fun showDetails(w:Wallpaper){
        val layout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(24),dp(24),dp(24),dp(24))}
        val image=ImageView(this).apply{adjustViewBounds=true;scaleType=ImageView.ScaleType.CENTER_CROP}
        Glide.with(this).load(w.path).into(image)
        layout.addView(image,LinearLayout.LayoutParams(-1,dp(420)))
        val fav=MaterialButton(this).apply{
            text=if(favorites.contains(w.id))"♥ Remove Favorite" else "♡ Favorite"
            setOnClickListener{
                val set=favorites.toMutableSet()
                if(!set.add(w.id))set.remove(w.id)
                prefs.edit().putStringSet("favorites",set).apply()
                text=if(set.contains(w.id))"♥ Remove Favorite" else "♡ Favorite"
            }
        }
        layout.addView(fav)
        val home=MaterialButton(this).apply{text="SET HOME";setOnClickListener{applyWallpaper(w.path,WallpaperManager.FLAG_SYSTEM)}}
        val lock=MaterialButton(this).apply{text="SET LOCK";setOnClickListener{applyWallpaper(w.path,WallpaperManager.FLAG_LOCK)}}
        val both=MaterialButton(this).apply{text="SET BOTH";setOnClickListener{applyWallpaper(w.path,3)}}
        val dl=MaterialButton(this).apply{text="DOWNLOAD";setOnClickListener{download(w.path)}}
        listOf(home,lock,both,dl).forEach{layout.addView(it)}
        MaterialAlertDialogBuilder(this).setTitle("AuraWall").setView(layout).setNegativeButton("Close",null).show()
    }

    private fun applyWallpaper(url:String,flags:Int){
        Glide.with(this).asBitmap().load(url).into(object:CustomTarget<Bitmap>(){
            override fun onResourceReady(b:Bitmap,t:Transition<in Bitmap>?){
                try{WallpaperManager.getInstance(this@MainActivity).setBitmap(b,null,true,flags);Toast.makeText(this@MainActivity,"Wallpaper applied!",Toast.LENGTH_SHORT).show()}
                catch(e:Exception){Toast.makeText(this@MainActivity,"Failed: ${e.message}",Toast.LENGTH_LONG).show()}
            }
            override fun onLoadCleared(d:android.graphics.drawable.Drawable?){}
        })
    }

    private fun download(url:String){
        Glide.with(this).asBitmap().load(url).into(object:CustomTarget<Bitmap>(){
            override fun onResourceReady(b:Bitmap,t:Transition<in Bitmap>?){
                try{
                    val dir=getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!
                    val f=File(dir,"AuraWall_${System.currentTimeMillis()}.jpg")
                    FileOutputStream(f).use{b.compress(Bitmap.CompressFormat.JPEG,95,it)}
                    Toast.makeText(this@MainActivity,"Saved ${f.name}",Toast.LENGTH_LONG).show()
                }catch(e:Exception){Toast.makeText(this@MainActivity,"Download failed",Toast.LENGTH_SHORT).show()}
            }
            override fun onLoadCleared(d:android.graphics.drawable.Drawable?){}
        })
    }
    private fun dp(value:Int):Int=(value*resources.displayMetrics.density).toInt()
}
