AURAWALL V3 — ANDROIDIDE EDITION

This version intentionally uses classic Android Views + RecyclerView instead of Compose to reduce mobile build complexity.

Recommended AndroidIDE:
- AndroidIDE 2.7.1-beta or a compatible fork.
- The archived official project documents JDK 17 and says AndroidIDE supports Android Gradle Plugin 7.2.0+; its v2.7.1 release notes specifically mention AGP 8.2.x support.
- This project uses AGP 8.2.2, Gradle 8.2, Kotlin 1.9.22.

BUILD:
1. Install AndroidIDE from a trusted source.
2. Open/import this extracted project.
3. Select JDK 17 if AndroidIDE asks.
4. Allow Gradle to download dependencies.
5. Build > Assemble Debug.
6. Install the generated app-debug.apk.

IMPORTANT:
- Internet is required.
- The app uses Wallhaven's public API and requests SFW content.
- This is a phone-buildable starter, not a guarantee that every AndroidIDE fork/version will build it without adjustment.
