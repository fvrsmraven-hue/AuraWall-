# AuraWall v3 — Cloud Build

AuraWall is an Android wallpaper app with online wallpapers, search, categories, favorites, downloads, and Home/Lock/Both wallpaper actions.

This version is prepared for **GitHub Actions cloud builds**, so AndroidIDE is not required.

See `CLOUD_BUILD.md` for phone-only build instructions.
