# AuraWall — Cloud Build (No PC / No AndroidIDE)

This project is prepared for a cloud build with GitHub Actions.

## What you need
- A GitHub account
- A phone browser (GitHub's website works on Android)
- Internet access

## Build steps
1. Create a new GitHub repository, for example `AuraWall`.
2. Upload the contents of this project to the repository. **Upload the files/folders inside this ZIP, not the ZIP itself.**
3. Open the repository's **Actions** tab.
4. Select **Build AuraWall APK**.
5. Tap **Run workflow**.
6. Wait for the green checkmark.
7. Open the completed workflow run.
8. Scroll to **Artifacts** and download **AuraWall-debug-apk**.
9. Extract the downloaded artifact and install the APK on your Android phone.

The workflow uses JDK 17 and Gradle 8.2 and builds the debug APK in the cloud. No AndroidIDE or PC is required.

## Important
- The debug APK is unsigned with a personal release key, so Android may show the normal warning for installing an APK from outside Play Store.
- The app currently uses the public Wallhaven API and needs internet access to load wallpapers.
- This is a debug build for testing. A Play Store/release build should use a proper signing key later.
